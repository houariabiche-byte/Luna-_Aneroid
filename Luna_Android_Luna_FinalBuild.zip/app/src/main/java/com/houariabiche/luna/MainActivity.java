package com.houariabiche.luna;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView view;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        view = new WebView(this);
        view.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView webView, String url) {
                return handleUrl(Uri.parse(url));
            }
        });
        view.setWebChromeClient(new WebChromeClient());
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        view.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        setContentView(view);
        view.loadUrl("file:///android_asset/index.html");
    }

    private boolean handleUrl(Uri uri) {
        String scheme = uri.getScheme();
        if (scheme == null || "file".equalsIgnoreCase(scheme) || "about".equalsIgnoreCase(scheme)) {
            return false;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception ignored) {
            // Keep Luna open if no installed app can handle this link.
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        if (view == null) {
            super.onBackPressed();
            return;
        }
        // Close the in-app task panel first; leave Luna only when no panel is open.
        view.evaluateJavascript(
            "document.getElementById('taskPanel')?.classList.contains('open') ? 'open' : 'closed'",
            value -> {
                if ("\"open\"".equals(value)) {
                    view.evaluateJavascript(
                        "document.getElementById('taskPanel')?.classList.remove('open')", null);
                } else {
                    MainActivity.super.onBackPressed();
                }
            }
        );
    }

    @Override
    protected void onDestroy() {
        if (view != null) {
            view.destroy();
            view = null;
        }
        super.onDestroy();
    }
}
