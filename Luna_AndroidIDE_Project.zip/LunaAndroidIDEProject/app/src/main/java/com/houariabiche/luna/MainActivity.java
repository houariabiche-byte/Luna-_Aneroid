package com.houariabiche.luna;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.content.Intent;
import android.net.Uri;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  WebView view = new WebView(this);
  view.setWebViewClient(new WebViewClient() {
   @Override public boolean shouldOverrideUrlLoading(WebView w, android.webkit.WebResourceRequest r) {
    Uri u=r.getUrl(); if ("file".equals(u.getScheme())) return false;
    try { startActivity(new Intent(Intent.ACTION_VIEW,u)); } catch (Exception ignored) {} return true;
   }
   @Override public boolean shouldOverrideUrlLoading(WebView w, String url) {
    if (url != null && url.startsWith("file:")) return false;
    try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url))); } catch (Exception ignored) {} return true;
   }
  });
  view.setWebChromeClient(new WebChromeClient());
  WebSettings s=view.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
  view.loadUrl("file:///android_asset/index.html"); setContentView(view);
 }
}
